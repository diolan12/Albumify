package com.netcode.songify.data.model.entity

data class ArtistEntity(
    val id: Int,
    val name: String,
    val bio: String,
    val link: String
)
