package com.netcode.songify.data.model.entity

data class AlbumEntity(
    val id: Int,
    val name: String,
    val art: Int,
    val year: Int,
    val link: String,
    val artist: Int
)
