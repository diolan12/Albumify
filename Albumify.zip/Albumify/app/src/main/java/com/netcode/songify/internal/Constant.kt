package com.netcode.songify.internal

object Constant {
    const val GENRE_KPOP = "K-Pop"
    const val GENRE_POP = "Pop"
    const val GENRE_FOLK = "Folk"
    const val GENRE_ROCK = "Rock"
    const val GENRE_HIPHOP = "Hip Hop"
    const val GENRE_ALTINDIE = "Alternative/Indie"
}
